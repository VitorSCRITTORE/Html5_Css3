ENGLISH:

Be very careful and take the time to read any terms & conditions before deciding
to use the font commercially. Ignorance is not an excuse for breaking the law.

By installing or using this font, you are hereby agree to this Font Usage Agreement:

1. This font is ONLY FOR PERSONAL USE purposes.
2. NO PROMOTIONAL & COMMERCIAL USE ALLOWED
3. You are REQUIRES A LICENSE for Promotional or Commercial Use
4. CONTACT ME before any Promotional or Commercial Use

------------------------------------------------------------------------------------------------------------------------------

- Email Support: ronnystd13@gmail.com

- Link to purchase full version and standart license: https://ronny-studio.com/b/slugs-racer-racing-display-font

- customize the license to your needs here : https://www.ronny-studio.com

- Paypal account for donation : https://www.paypal.me/ronyrizki13

- And follow our Behance for update : https://www.behance.net/ronnystudio

------------------------------------------------------------------------------------------------------------------------------

INDONESIA:

Berhati-hatilah dan luangkan waktu untuk membaca Syarat & Ketentuan penggunaan font,   
sebelum memutuskan untuk menggunakan font secara komersial.
Ketidaktahuan bukanlah alasan untuk sebuah pelanggaran hukum.

Dengan meng-install font ini, anda dianggap mengerti dan menyetujui
semua Syarat & Ketentuan penggunaan font dibawah ini:

1. Lisensi font ini adalah "Personal Use".
Yang berarti font ini hanya boleh digunakan untuk keperluan pribadi yang sifatnya tidak komersil,
atau tidak menghasilkan profit atau keuntungan, materiil maupun non-materiil.
Baik itu untuk Perorangan/Individual, Agensi Desain Grafis & Periklanan, Percetakan,
dan Perusahaan/Korporasi.

2. DILARANG KERAS menggandakan, mendistribusikan, dan menggunakan font ini
untuk keperluan komersial. Baik itu untuk Iklan, Promosi, TV, Film, Video, Motion Graphic,
Youtube, atau untuk Logo & Kemasan Produk ( Fisik maupun Digital), atau dalam media apapun
dengan tujuan menghasilkan profit atau keuntungan, materiil maupun non-materiil.

3. Menggandakan, mendistribusikan, dan menggunakan font ini untuk keperluan komersial
apapun jenis & bentuknya, TANPA IZIN atau TANPA MEMBELI LISENSI font terlebih dahulu
dari saya sebagai Pencipta dan/atau Pemegang Hak Cipta font, akan dikenakan biaya
Extended License dengan harga 100 kali harga Standard License, atau sesuai dengan
ketentuan yang telah diatur dalam Undang-Undang Nomor 28 Tahun 2014 Tentang Hak Cipta
yang berlaku di Negara Kesatuan Republik Indonesia.

Informasi tentang Lisensi apa yang akan anda perlukan, silahkan menghubungi saya:
Email: ronnystd13@gmail.com

Thank you.